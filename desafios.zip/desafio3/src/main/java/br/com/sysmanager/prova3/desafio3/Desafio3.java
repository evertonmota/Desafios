package br.com.sysmanager.prova3.desafio3;

import java.util.Scanner;

public class Desafio3 {
	
	//Fibonacci ex :. 1 . 1 . 2 . 3 . 5 . 8 . 13 . 21 ... 
	public static int geraFibonacci(int n) {
		if( n == 1 || n ==0) 
			return 1;
			return geraFibonacci( n -1) + geraFibonacci(n-2);
	}

	public static void main(String[] args) {

		Scanner sc1 = new Scanner(System.in);
		System.out.print("Digite o primeiro n�mero: ");
		Integer n1 = sc1.nextInt();
		
		if( n1 <= 20) {
			for(int i =0 ; i < n1; i++) {
				System.out.println("Posi��o " + (i + 1) + " = " + geraFibonacci(i) + " ");
			}
		}else {
			System.out.println(" Valor M�ximo de Fibonacci � 20 ");
		}
	}

}
