package br.com.sysmanager.prova2.desafio2;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

	public class Desafio2 {
		
		public static void main(String[] args) {
			
			Scanner sc1 = new Scanner(System.in);
			
			System.out.print("Digite a primeira palavra para criptografar : ");
			String p1 = sc1.nextLine();
			System.out.println(criptografa(p1.toUpperCase()));
			
			Scanner sc2 = new Scanner(System.in);
			System.out.print("Digite a palavra para descriptografa: ");
			String p2 = sc2.nextLine();
			System.out.println(descriptografa(p2.toUpperCase()));
			
		}
		
		public static String criptografa(String texto) {
			List<String> lista = Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "A", "B", "C");
			return processa(texto, lista);
		}
		
		public static String descriptografa(String texto) {
			List<String> lista = Arrays.asList("C", "B", "A", "Z", "Y", "X", "W", "V", "U", "T", "S", "R", "Q", "P", "O", "N", "M", "L", "K", "J", "I", "H", "G", "F", "E", "D", "C", "B", "A");
			return processa(texto, lista);
		}	
		
		public static String processa(String texto, List<String> lista) {
			
			String cripto = "";

			for (int i = 1; i <= texto.length(); i++) {
				if (lista.contains(texto.substring(i-1, i))) {
					for (int j = 0; j < lista.size() - 3; j++) {
						
						if (texto.substring(i-1, i).equals(lista.get(j))) {
							cripto = cripto + lista.get(j + 3);
						}
					}
				} else {
					cripto = cripto + texto.substring(i-1, i);
				}
			}
			return cripto;
		}

	}


