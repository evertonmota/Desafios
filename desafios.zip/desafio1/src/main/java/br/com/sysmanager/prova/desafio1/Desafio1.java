package br.com.sysmanager.prova.desafio1;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Desafio1 {
	
	public static void main(String[] args) {
		Scanner sc1 = new Scanner(System.in);
		
		System.out.print("Digite o primeiro n�mero: ");
		Integer n1 = sc1.nextInt();
		
		System.out.print("Digite o segundo n�mero: ");
		Integer n2 = sc1.nextInt();
	    
		System.out.println("O maior n�mero primo encontrado �: " + encontraMaiorPrimo(n1, n2));

	    sc1.close();
	}
	
	public static Integer encontraMaiorPrimo(Integer n1, Integer n2) {
		
		Integer menor = n1 < n2 ? n1 : n2;
		Integer maior = n1 > n2 ? n1 : n2;
		
		List<Integer> primos = new ArrayList<Integer>();
		for (int i = menor; i <= maior; i++ ) {
			primos.add(i);
		}
		
    	return primos.stream().filter(e -> ePrimo(e)).max(Comparator.naturalOrder()).get();
	}
	
	public static Boolean ePrimo(Integer numero) {
        for (int i = 2; i < numero; i++) {
            if (numero % i == 0)
                return false;   
        }
        return true;
		
	}

}